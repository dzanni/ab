#SXD20|20006|50140|50204|2010.06.15 19:33:17|diplom|0|18|164|
#TA coreDataCategory`92`20276|coreDataTable`3`39212|curs`3`60|data`4`148|discount`4`52|firm`13`332|grp`2`52|maket`5`304|moduleData`3`152|modules`7`596|news`1`60|options`2`48|orderData`7`224|orders`6`616|shablon`6`412|spec`2`42|tovar`2`492|users`2`284
#EOH

#	TC`coreDataCategory`utf8_general_ci	;
CREATE TABLE `coreDataCategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  `description` text NOT NULL,
  `pageTitle` text NOT NULL,
  `position` float(26,19) NOT NULL DEFAULT '0.0000000000000000000',
  `shablon` int(11) NOT NULL,
  `maket` int(11) NOT NULL,
  `enURL` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=99 DEFAULT CHARSET=utf8 COMMENT='Категории товаров'	;
#	TD`coreDataCategory`utf8_general_ci	;
INSERT INTO `coreDataCategory` VALUES 
(1,'Мебель',90,'Мебель','Мебель','Мебель',4.0000000000000000000,0,0,'Mebel',0),
(3,'Мебельная фурнитура',90,'','','',2.0000000000000000000,0,0,'Mebelnaya-furnitura',0),
(4,'Мебель для гостинной',1,'','','',0.0000000000000000000,0,0,'Mebel-dlya-gostinnoy',0),
(5,'Мебель для кухни',1,'','','',0.0000000000000000000,0,0,'Mebel-dlya-kuhni',0),
(6,'Шкафы',4,'','','',0.0000000000000000000,0,0,'SHkafi',0),
(7,'Жалюзи',90,'','','Жалюзи',0.0000000000000000000,0,0,'ZHalyuzi',0),
(8,'Горизонтальные',7,'Жалюзи. вертикальные жалюзи ,горизонтальные жалюзи, верт, гор, горизонт,окна, двери, дом, дизайн, камин,рис,рисунок,','','Горизонтальные',0.0000000000000000000,0,0,'Gorizontalnie',0),
(9,'Шторы',90,'шт, плисс,плиссированные шторы, рул, рулон, рулонные шторы,окна, жалюзи, верт, вертикальные жалюзи, горизонтальные жалюзи,','','Шторы',0.0000000000000000000,0,0,'SHtori',0),
(10,'Вертикальные',7,'Жалюзи. вертикальные жалюзи ,горизонтальные жалюзи, верт, гор, горизонт,окна, двери, дом, дизайн, камин,рис,рисунок,','','Вертикальные',0.0000000000000000000,0,0,'Vertikalnie',0),
(11,'Реечные подвесные потолки',90,'реечные потолки, подвесные потолки, потолки  производства России, потолки производства Luxalon,','купите потолок, обновите ваш быт, сделайте себе приятное,','Реечные подвесные потолки',0.0000000000000000000,0,0,'Reechnie-podvesnie-potolki',0),
(12,'Натяжные потолки',90,'натяжной потолок, французские потолки, покраска натяжного потолка, потолок klipso, потолок  клипсо, производство швейцария,','быстро качественно и надежно, цена низкая, пропан, газ, профиль металлический или пластиковый','Натяжные потолки',0.0000000000000000000,0,0,'Natyazhnie-potolki',0),
(13,'Окна',90,'окна, оконная система, металлопластиковые окна, однокамерный стеклопакет, двухкамерный пакет, откосы, подоконники, установка, монтаж, пена монтажная, запенить проем, покрасить откос, гарантия, страховка, механизм, производитель, супер окна, слухоизоляция,вентиляция, кондиционер, микропроветривание,ручка,балконная ручка, мансардные окна GVT.','Заказ расчет и установка все в короткие сроки, качество и гарантия. Не отстовайте от нас, мы шагаем со временем.','Окна',0.0000000000000000000,0,0,'Okna',0),
(14,'Двери',90,'окна, оконная система, металлопластиковые окна, однокамерный стеклопакет, двухкамерный пакет, откосы, подоконники, установка, монтаж, пена монтажная, запенить проем, покрасить откос, гарантия, страховка, механизм, производитель, супер окна, слухоизоляция,вентиляция, кондиционер, микропроветривание,ручка,балконная ручка, мансардные окна GVT.Двери, арки,крашенные двери , пластик цвета по образцу','От Элитных до оптимальных все зависет от вас и вашей возможности.','Двери',0.0000000000000000000,0,0,'Dveri',0),
(15,'Петли и кронштейны',3,'Петли, рояльные петли, петли дверные, мебельные накладные, накладные петли, полунакладные петли, скрытые петли, саморезы к петлям, размер петель, тип петель, что такое петля, купить петли, поменять петли,','Продадим, установим, обновим, все.','Петли и кронштейны',0.0000000000000000000,0,0,'Petli-i-kronshteyni',0),
(16,'Мебельные ручки',3,'Мебельные ручки, хром, золото, полумат, мат, размер, тип, ручки для фасадов, ручки кухонные, ручка любимая,','Ручка слово многозначещее.','Мебельные ручки',0.0000000000000000000,0,0,'Mebelnie-ruchki',0),
(17,'Крючок',3,'Крючок, большой крючок, золотой крючек','Крючок','Крючок',0.0000000000000000000,0,0,'Kryuchok',0),
(18,'Направляющие и металлобоксы',3,'','','Направляющие и металлобоксы',0.0000000000000000000,0,0,'Napravlyayushchie-i-metalloboksi',0),
(19,'Системы для шкафов купе',3,'','','Системы для шкафов купе',0.0000000000000000000,0,0,'Sistemi-dlya-shkafov-kupe',0),
(20,'Мебельные ножки и опоры',3,'Мебельные ножки и опоры','Мебельные ножки и опоры','Мебельные ножки и опоры',0.0000000000000000000,0,0,'Mebelnie-nozhki-i-opori',0),
(21,'Мебельная фурнитура для кухонь',3,'Мебельная фурнитура для кухонь','Мебельная фурнитура для кухонь','Мебельная фурнитура для кухонь',0.0000000000000000000,0,0,'Mebelnaya-furnitura-dlya-kuhon',0),
(22,'Полкодержатели',3,'Полкодержатели','Полкодержатели','Полкодержатели',0.0000000000000000000,0,0,'Polkoderzhateli',0),
(23,'Комплектующие для торгового оборудования',3,'Комплектующие для торгового оборудования','Комплектующие для торгового оборудования','Комплектующие для торгового оборудования',0.0000000000000000000,0,0,'Komplektuyushchie-dlya-torgovogo-oborudovaniya',0),
(24,'Крепежные материаллы',3,'Крепежные материаллы','Крепежные материаллы','Крепежные материаллы',0.0000000000000000000,0,0,'Krepezhnie-materialli',0),
(25,'Светильники мебельные',3,'Светильники мебельные','Светильники мебельные','Светильники мебельные',0.0000000000000000000,0,0,'Svetilniki-mebelnie',0),
(26,'Наполнения для шкафов, замки, амортизаторы',3,'Наполнения для шкафов, замки, амортизаторы','Наполнения для шкафов, замки, амортизаторы','Наполнения для шкафов, замки, амортизаторы',0.0000000000000000000,0,0,'Napolneniya-dlya-shkafov-zamki-amortizatori',0),
(27,'Мебельная фурнитура',3,'Мебельная фурнитура','Мебельная фурнитура','Мебельная фурнитура',0.0000000000000000000,0,0,'Mebelnaya-furnitura',0),
(28,'Клей и ремонтные материаллы',3,'Клей и ремонтные материаллы','Клей и ремонтные материаллы','Клей и ремонтные материаллы',0.0000000000000000000,0,0,'Kley-i-remontnie-materialli',0),
(29,'Уход за мебелью',3,'Уход за мебелью','Уход за мебелью','Уход за мебелью',0.0000000000000000000,0,0,'Uhod-za-mebelyu',0),
(30,'Ручки врезные',16,'Ручки врезные','Ручки врезные','Ручки врезные',0.0000000000000000000,0,0,'Ruchki-vreznie',0),
(31,'Ручки мебельные',16,'Ручки мебельные','Ручки мебельные','Ручки мебельные',0.0000000000000000000,0,0,'Ruchki-mebelnie',0),
(32,'Ручки рейлинговые',16,'Ручки рейлинговые','Ручки рейлинговые','Ручки рейлинговые',0.0000000000000000000,0,0,'Ruchki-reylingovie',0),
(33,'Шайбы для ручек',16,'Шайбы для ручек','Шайбы для ручек','Шайбы для ручек',0.0000000000000000000,0,0,'SHaybi-dlya-ruchek',0),
(34,'Направляющие роликовые',18,'Направляющие роликовые','Направляющие роликовые','Направляющие роликовые',0.0000000000000000000,0,0,'Napravlyayushchie-rolikovie',0),
(35,'Металлобоксы',18,'Металлобоксы','Металлобоксы','Металлобоксы',0.0000000000000000000,0,0,'Metalloboksi',0),
(36,'Направляющие роликовые (ширина 35 мм.)',18,'Направляющие роликовые (ширина 35 мм.)','Направляющие роликовые (ширина 35 мм.)','Направляющие роликовые (ширина 35 мм.)',0.0000000000000000000,0,0,'Napravlyayushchie-rolikovie-shirina-35-mm',0),
(37,'Направляющие роликовые (ширина 45 мм.)',18,'Направляющие роликовые (ширина 45 мм.)','Направляющие роликовые (ширина 45 мм.)','Направляющие роликовые (ширина 45 мм.)',0.0000000000000000000,0,0,'Napravlyayushchie-rolikovie-shirina-45-mm',0),
(38,'Направляющие и полки для клавиатуры',18,'Направляющие и полки для клавиатуры','Направляющие и полки для клавиатуры','Направляющие и полки для клавиатуры',0.0000000000000000000,0,0,'Napravlyayushchie-i-polki-dlya-klaviaturi',0),
(39,'Аллюминиевая система',19,'Аллюминиевая система','Аллюминиевая система','Аллюминиевая система',0.0000000000000000000,0,0,'Allyuminievaya-sistema',0),
(40,'Система Командор',19,'Система Командор','Система Командор','Система Командор',0.0000000000000000000,0,0,'Sistema-Komandor',0),
(41,'Система Консул',19,'Система Консул','Система Консул','Система Консул',0.0000000000000000000,0,0,'Sistema-Konsul',0),
(42,'Система СКМ',19,'Система СКМ','Система СКМ','Система СКМ',0.0000000000000000000,0,0,'Sistema-SKM',0),
(43,'Буферная лента и уплотнители',19,'Буферная лента и уплотнители','Буферная лента и уплотнители','Буферная лента и уплотнители',0.0000000000000000000,0,0,'Bufernaya-lenta-i-uplotniteli',0),
(44,'Мебельные ноги d = 60 мм.',20,'Мебельные ноги d = 60 мм.','Мебельные ноги d = 60 мм.','Мебельные ноги d = 60 мм.',0.0000000000000000000,0,0,'Mebelnie-nogi-d--60-mm',0),
(45,'Ножки цокольные',20,'Ножки цокольные','Ножки цокольные','Ножки цокольные',0.0000000000000000000,0,0,'Nozhki-tsokolnie',0),
(46,'Опоры для шкафов и мягкой мебели',20,'Опоры для шкафов и мягкой мебели','Опоры для шкафов и мягкой мебели','Опоры для шкафов и мягкой мебели',0.0000000000000000000,0,0,'Opori-dlya-shkafov-i-myagkoy-mebeli',0),
(47,'Опоры колесные',20,'Опоры колесные','Опоры колесные','Опоры колесные',0.0000000000000000000,0,0,'Opori-kolesnie',0),
(48,'Подпятники',20,'Подпятники','Подпятники','Подпятники',0.0000000000000000000,0,0,'Podpyatniki',0),
(49,'Барные трубы (d = 50 мм.)',21,'Барные трубы (d = 50 мм.)','Барные трубы (d = 50 мм.)','Барные трубы (d = 50 мм.)',0.0000000000000000000,0,0,'Barnie-trubi-d--50-mm',0),
(50,'Выдвижные механизмы для кухни',21,'Выдвижные механизмы для кухни','Выдвижные механизмы для кухни','Выдвижные механизмы для кухни',0.0000000000000000000,0,0,'Vidvizhnie-mehanizmi-dlya-kuhni',0),
(51,'Мойки',21,'Мойки','Мойки','Мойки',0.0000000000000000000,0,0,'Moyki',0),
(52,'Рейлинги',21,'Рейлинги','Рейлинги','Рейлинги',0.0000000000000000000,0,0,'Reylingi',0),
(53,'Полки для рейлинга',21,'Полки для рейлинга','Полки для рейлинга','Полки для рейлинга',0.0000000000000000000,0,0,'Polki-dlya-reylinga',0),
(54,'Аксесуары для кухни',21,'Аксесуары для кухни','Аксесуары для кухни','Аксесуары для кухни',0.0000000000000000000,0,0,'Aksesuari-dlya-kuhni',0),
(55,'Полкодержатели',22,'Полкодержатели','Полкодержатели','Полкодержатели',0.0000000000000000000,0,0,'Polkoderzhateli',0),
(56,'Полкодержатели- пеликаны',22,'Полкодержатели- пеликаны','Полкодержатели- пеликаны','Полкодержатели- пеликаны',0.0000000000000000000,0,0,'Polkoderzhateli--pelikani',0),
(57,'Консоли',22,'Консоли','Консоли','Консоли',0.0000000000000000000,0,0,'Konsoli',0),
(58,'Трубы d = 25 мм.',23,'Трубы d = 25 мм.','Трубы d = 25 мм.','Трубы d = 25 мм.',0.0000000000000000000,0,0,'Trubi-d--25-mm',0),
(59,'Джокер (Италия)',23,'Джокер (Италия)','Джокер (Италия)','Джокер (Италия)',0.0000000000000000000,0,0,'Dzhoker-Italiya',0),
(60,'Джокер Китай',23,'Джокер Китай','Джокер Китай','Джокер Китай',0.0000000000000000000,0,0,'Dzhoker-Kitay',0),
(61,'Система Real и Микрон',23,'Система Real и Микрон','Система Real и Микрон','Система Real и Микрон',0.0000000000000000000,0,0,'Sistema-Real-i-Mikron',0),
(62,'Заглушки',24,'Заглушки','Заглушки','Заглушки',0.0000000000000000000,0,0,'Zaglushki',0),
(63,'Навесы',24,'Навесы','Навесы','Навесы',0.0000000000000000000,0,0,'Navesi',0),
(64,'Стяжки саморезные',24,'Стяжки саморезные','Стяжки саморезные','Стяжки саморезные',0.0000000000000000000,0,0,'Styazhki-samoreznie',0),
(65,'Уголки',24,'Уголки','Уголки','Уголки',0.0000000000000000000,0,0,'Ugolki',0),
(66,'Шурупы',24,'Шурупы','Шурупы','Шурупы',0.0000000000000000000,0,0,'SHurupi',0),
(67,'Прочий крепеж',24,'Прочий крепеж','Прочий крепеж','Прочий крепеж',0.0000000000000000000,0,0,'Prochiy-krepezh',0),
(68,'Светильники',25,'Светильники','Светильники','Светильники',0.0000000000000000000,0,0,'Svetilniki',0),
(69,'Электрика',25,'Электрика','Электрика','Электрика',0.0000000000000000000,0,0,'Elektrika',0),
(70,'Готовые комплекты светильников',25,'Готовые комплекты светильников','Готовые комплекты светильников','Готовые комплекты светильников',0.0000000000000000000,0,0,'Gotovie-komplekti-svetilnikov',0),
(71,'Петли четырехшарнирные Ferrari (Италия)',15,'Петли четырехшарнирные Ferrari (Италия)','Петли четырехшарнирные Ferrari (Италия)','Петли четырехшарнирные Ferrari (Италия)',0.0000000000000000000,0,0,'Petli-chetirehsharnirnie-Ferrari-Italiya',0),
(73,'Петли четырехшарнирные (Китай)',15,'Петли четырехшарнирные (Китай)','Петли четырехшарнирные (Китай)','Петли четырехшарнирные (Китай)',0.0000000000000000000,0,0,'Petli-chetirehsharnirnie-Kitay',0),
(74,'Кронштейны, газ- лифты, и другие петли.',15,'Кронштейны, газ- лифты, и другие петли.','Кронштейны, газ- лифты, и другие петли.','Кронштейны, газ- лифты, и другие петли.',0.0000000000000000000,0,0,'Kronshteyni-gaz--lifti-i-drugie-petli',0),
(75,'Клей расплав и контактный клей',28,'Клей расплав и контактный клей','Клей расплав и контактный клей','Клей расплав и контактный клей',0.0000000000000000000,0,0,'Kley-rasplav-i-kontaktniy-kley',0),
(76,'Мягкий ремонтный воск',28,'Мягкий ремонтный воск','Мягкий ремонтный воск','Мягкий ремонтный воск',0.0000000000000000000,0,0,'Myagkiy-remontniy-vosk',0),
(77,'Наполнения для шкафов',3,'Наполнения для шкафов','Наполнения для шкафов','Наполнения для шкафов',0.0000000000000000000,0,0,'Napolneniya-dlya-shkafov',0),
(78,'Замки, амортизаторы и пр. мебельная фурнитура',3,'Замки, амортизаторы и пр. мебельная фурнитура','Замки, амортизаторы и пр. мебельная фурнитура','Замки, амортизаторы и пр. мебельная фурнитура',0.0000000000000000000,0,0,'Zamki-amortizatori-i-pr-mebelnaya-furnitura',0),
(79,'Вешалки выдвижные',77,'Вешалки выдвижные','Вешалки выдвижные','Вешалки выдвижные',0.0000000000000000000,0,0,'Veshalki-vidvizhnie',0),
(80,'Одежные штанги 30 Х 15 мм.',77,'Одежные штанги 30 Х 15 мм.','Одежные штанги 30 Х 15 мм.','Одежные штанги 30 Х 15 мм.',0.0000000000000000000,0,0,'Odezhnie-shtangi-30-H-15-mm',0),
(81,'Полки для обуви',77,'Полки для обуви','Полки для обуви','Полки для обуви',0.0000000000000000000,0,0,'Polki-dlya-obuvi',0),
(82,'Галстучницы и держатели для брюк',77,'Галстучницы и держатели для брюк','Галстучницы и держатели для брюк','Галстучницы и держатели для брюк',0.0000000000000000000,0,0,'Galstuchnitsi-i-derzhateli-dlya-bryuk',0),
(83,'Пантографы',77,'Пантографы','Пантографы','Пантографы',0.0000000000000000000,0,0,'Pantografi',0),
(84,'Заглушки для проводки',78,'Заглушки для проводки','Заглушки для проводки','Заглушки для проводки',0.0000000000000000000,0,0,'Zaglushki-dlya-provodki',0),
(85,'Замки, шпингалеты, защелки и пр.',78,'Замки, шпингалеты, защелки и пр.','Замки, шпингалеты, защелки и пр.','Замки, шпингалеты, защелки и пр.',0.0000000000000000000,0,0,'Zamki-shpingaleti-zashchelki-i-pr',0),
(86,'Зеркалодержатели',78,'Зеркалодержатели','Зеркалодержатели','Зеркалодержатели',0.0000000000000000000,0,0,'Zerkaloderzhateli',0),
(87,'Для CD и DVD',78,'Для CD и DVD','Для CD и DVD','Для CD и DVD',0.0000000000000000000,0,0,'Dlya-CD-i-DVD',0),
(88,'Профиль для стекол',78,'Профиль для стекол','Профиль для стекол','Профиль для стекол',0.0000000000000000000,0,0,'Profil-dlya-stekol',0),
(89,'Другое',78,'Другое','Другое','Другое',0.0000000000000000000,0,0,'Drugoe',0),
(90,'Каталог',0,'','','Каталог',-2.0000000000000000000,5,0,'Katalog',0),
(97,'Контакты',0,'','','Контакты',0.0000000000000000000,0,24,'Kontakti',0),
(95,'О компании',0,'Ключевые слова для компании','Главное о компании','О компании',2.0000000000000000000,0,0,'O-kompanii',0),
(96,'ДОСТАВКА',14,'Доставка, доставка, доставка на дом, доставка+на дом, доставка товаров, курьерская доставка, курьерская, перевозка автотранспортом, курьерская почта, срочная доставка, доставка почтой, экспресс доставка, доставка кухни, доставка окон, пластиковые окна доставка, пластиковые окна доставка+установка, доставка шкафов купе, доставка шкафов, доставка+установка, доставка и сборка мебели, доставка и установка дверей, перевозки, доставка и установка жалюзи, доставка в городе и области, сервис , доставить по адресу,','Доставка АКТИВ ПЛЮС, известная своим интернет магазином строительных материалов, мебели, и аксессуаров для обустройства жилого помещения, а также интернет магазином shop-gvt.ru. Все для отдыха. Активно использует информационные технологии.','ДОСТАВКА',10.0000000000000000000,0,0,'DOSTAVKA',0),
(0,'Сайт',-1,'Сайт','Сайт','Сайт',0.0000000000000000000,1,25,'',0)	;
#	TC`coreDataTable`utf8_general_ci	;
CREATE TABLE `coreDataTable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  `position` float(26,19) NOT NULL DEFAULT '0.0000000000000000000',
  `coreDataCategory` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8	;
#	TD`coreDataTable`utf8_general_ci	;
INSERT INTO `coreDataTable` VALUES 
(3,'&lt;p&gt;ООО. «АКТИВ ПЛЮС»\n\nЭто Российская компания, работающая в индустрии (производство и строительство) нацеленная на улучшение жизни людей, используя современные технологии. Являясь лидером в области производства мебели (кухни, прихожие, шкафы- купе) и обустройства мест для их размещения.&lt;/p&gt;&lt;p&gt;ООО. «АКТИВ ПЛЮС» - в своих технологических и дизайнерских решениях ориентируется на людей. Потребности потребителей и принцип  “ быстро и качественно” лежат в основе всех разработок  ООО.  «АКТИВ ПЛЮС». Это не только грамотный подход к делу!!!                                 ООО. «АКТИВ ПЛЮС» - это и школа для подрастающего поколения, школа для подростков, которые хотят научится,  делать что-нибудь руками.\n\nРуководство,  ООО.&lt;/p&gt;&lt;p&gt;«АКТИВ ПЛЮС» принимает активное участие в разработке обучающих программ  для начинающих специалистов. Присылайте Вашу  автобиографию (резюме)  на наш почтовый ящик  aktiveplus777@yandex.ru , мы с радостью поделимся с Вами нашим опытом. Адрес нашего сайта www.aktiveplus.ru&lt;/p&gt;',0.0000000000000000000,0),
(4,'Доставка: Актив Плюс\n\nОтдел доставки: www.aktiveplus.ru\nКомпания OOO.&quot;АКТИВ ПЛЮС&quot; Россия.190020 Санкт-Петербург. ул. Курляндская д.46,лит А, пом 17Н.\nСвои предложения Вы можете направлять на aktiveplus777@yandex.ru. Мы рассматриваем все Предложения, касающиеся качественных товаров по взаимовыгодным ценам с обеспечением бесперебойности поставок. Для ускорения сроков рассмотрения Вашего Предложения, просим Вас заполнить все необходимые поля прилагаемых бланков (Приложения №1-2).\nКаталоги Вашей продукции Вы можете предоставить по электронной почте, доставить лично или экспресс - почтой (обычной почтой) по адресу: 192283 Россия: Санкт-Петербург ул. Будапештская д108/24 кв.31\nПросьба, при доставке каталога почтой, указать дату отправки Вашего Коммерческого предложения. Каталоги и образцы продукции не возвращаются.\nОбратите внимание, что при составлении Коммерческого предложения прайс-лист на товары указывается в рублях с учетом налога на добавленную стоимость, в отдельном поле указывается налоговая ставка (18%, 10%) или делается отметка об освобождении от налогообложения.\nМы гарантируем Вам, что направленные в наш адрес предложения будут прочитаны в течение 45 календарных дней.\nПо всем вопросам, относительно рассмотрения предложений, Вы можете обращаться по электронной почте aktiveplus777@yandex.ru\n\nКонтактный телефон:\nРоссия: Санкт – Петербург +7904-336-03-03: или (812) 947 73 39\n\nДоставка товаров на дом\nУсловия доставки  АКТИВ ПЛЮС. Выдержка из договора доставки:\nI. Исполнитель обязуется\n1. Доставить товар в согласованный сторонами день с 11-00 до 17-00 или с 17-00 до 22-00 часов (указывается конкретно) по адресу, указанному Заказчиком, с учетом произведенной оплаты.\n2. Поднять товар в квартиру в соответствии с произведенной оплатой согласно утвержденным по предприятию тарифам,\nII. Заказчик обязуется\n1. Находиться в указанные строки по месту доставки товара, либо обеспечить дееспособное лицо вышеуказанными полномочиями. В случае невыполнения условий, указанных в п. II.1, доставка товара осуществляется Заказчиком самостоятельно или оплачивается повторно Исполнителю.\n2. В случае несоответствия габаритов товара при его подъеме в квартиру размерам лестничных, дверных проемов, приемка товара Заказчиком осуществляется у двери подъезда дома. Обязанности по доставке товара считаются исполненными. Возврат денежных средств за подъем товара производится Исполнителем на основании письменного заявления Заказчика в доле, приходящейся на товар, подъем которого не производился.\n3. Дополнительная разборка товара (мебели) для подъема в квартиру Исполнителем не производится. Разборка товара (мебели) должна учитываться Заказчиком и согласовываться с продавцом при заключении Договора купли-продажи.\n4. Наличие чрезвычайных и непредотвратимых обстоятельств (природные или общественные явления), случайных обстоятельств, препятствующих безопасному проезду автомобиля к месту или в месте выгрузки товара (прорыв магистралей, прокладка траншей, отсутствие или повреждение подъездных путей, иное), освобождает Исполнителя от ответственности за нарушение принятых обязательств. Доставка товара осуществляется Заказчиком самостоятельно или оплачивается повторно и осуществляется после устранения вышеуказанных обстоятельств.\nСтоимость доставки\nДействуют следующие тарифы на услуги по доставке товара покупателям:\n• Стоимость доставки в радиусе 10 км от магазина — 400 руб.;\n• Стоимость доставки в радиусе 20 км от магазина — 680 руб.;\n• Стоимость доставки в радиусе 30 км от магазина — 940 руб.;\n• Стоимость доставки в радиусе 40 км от магазина — 1300 руб.;\n• Стоимость доставки в радиусе 50 км от магазина — 1450 руб.\nЗаказ на доставку оформляется при суммарном весе товара до 3000 кг. В случае необходимости доставки товара весом более 3000 кг, оформляется два (или более) заказа на доставку с отдельной оплатой по каждому заказу.\nДоставка товара на расстояние свыше 50 км осуществляется в индивидуальном порядке по согласованию с дирекцией магазина.\nВо всех случаях доставка товара осуществляется до входной двери в подъезд или до входной двери в загородный дом.\nПри получении товара покупатель должен проверить соответствие полученного товара заказанному, а также произвести внешний осмотр товара на предмет выявления механических повреждений и других видимых дефектов.\nПосле приемки товара претензии к количеству комплектности и внешним дефектам – не принимаются.\nПокупатель вправе отказаться от товара в любое время до передачи товара, а после передачи товара в течение, 7 дней. Возврат товара возможен в случае сохранения надлежащего товарного вида товара и сохранения, документов подтверждающих покупку данного товара.\nПретензии к товару принимаются при наличии товарного и кассового чека, по телефону\nРоссия: Санкт-Петербург (812) 9477339',0.0000000000000000000,96),
(5,'&lt;meta http-equiv=&quot;Content-Type&quot; content=&quot;text/html; charset=utf-8&quot;&gt;&lt;meta name=&quot;ProgId&quot; content=&quot;Word.Document&quot;&gt;&lt;meta name=&quot;Generator&quot; content=&quot;Microsoft Word 12&quot;&gt;&lt;meta name=&quot;Originator&quot; content=&quot;Microsoft Word 12&quot;&gt;&lt;link rel=&quot;File-List&quot; href=&quot;file:///C:%5CUsers%5Cuser%5CAppData%5CLocal%5CTemp%5Cmsohtmlclip1%5C01%5Cclip_filelist.xml&quot;&gt;&lt;link rel=&quot;themeData&quot; href=&quot;file:///C:%5CUsers%5Cuser%5CAppData%5CLocal%5CTemp%5Cmsohtmlclip1%5C01%5Cclip_themedata.thmx&quot;&gt;&lt;link rel=&quot;colorSchemeMapping&quot; href=&quot;file:///C:%5CUsers%5Cuser%5CAppData%5CLocal%5CTemp%5Cmsohtmlclip1%5C01%5Cclip_colorschememapping.xml&quot;&gt;&lt;!--[if gte mso 9]&gt;&lt;xml&gt;\n &lt;w:WordDocument&gt;\n  &lt;w:View&gt;Normal&lt;/w:View&gt;\n  &lt;w:Zoom&gt;0&lt;/w:Zoom&gt;\n  &lt;w:TrackMoves/&gt;\n  &lt;w:TrackFormatting/&gt;\n  &lt;w:PunctuationKerning/&gt;\n  &lt;w:ValidateAgainstSchemas/&gt;\n  &lt;w:SaveIfXMLInvalid&gt;false&lt;/w:SaveIfXMLInvalid&gt;\n  &lt;w:IgnoreMixedContent&gt;false&lt;/w:IgnoreMixedContent&gt;\n  &lt;w:AlwaysShowPlaceholderText&gt;false&lt;/w:AlwaysShowPlaceholderText&gt;\n  &lt;w:DoNotPromoteQF/&gt;\n  &lt;w:LidThemeOther&gt;RU&lt;/w:LidThemeOther&gt;\n  &lt;w:LidThemeAsian&gt;X-NONE&lt;/w:LidThemeAsian&gt;\n  &lt;w:LidThemeComplexScript&gt;X-NONE&lt;/w:LidThemeComplexScript&gt;\n  &lt;w:Compatibility&gt;\n   &lt;w:BreakWrappedTables/&gt;\n   &lt;w:SnapToGridInCell/&gt;\n   &lt;w:WrapTextWithPunct/&gt;\n   &lt;w:UseAsianBreakRules/&gt;\n   &lt;w:DontGrowAutofit/&gt;\n   &lt;w:SplitPgBreakAndParaMark/&gt;\n   &lt;w:DontVertAlignCellWithSp/&gt;\n   &lt;w:DontBreakConstrainedForcedTables/&gt;\n   &lt;w:DontVertAlignInTxbx/&gt;\n   &lt;w:Word11KerningPairs/&gt;\n   &lt;w:CachedColBalance/&gt;\n  &lt;/w:Compatibility&gt;\n  &lt;w:BrowserLevel&gt;MicrosoftInternetExplorer4&lt;/w:BrowserLevel&gt;\n  &lt;m:mathPr&gt;\n   &lt;m:mathFont m:val=&quot;Cambria Math&quot;/&gt;\n   &lt;m:brkBin m:val=&quot;before&quot;/&gt;\n   &lt;m:brkBinSub m:val=&quot;--&quot;/&gt;\n   &lt;m:smallFrac m:val=&quot;off&quot;/&gt;\n   &lt;m:dispDef/&gt;\n   &lt;m:lMargin m:val=&quot;0&quot;/&gt;\n   &lt;m:rMargin m:val=&quot;0&quot;/&gt;\n   &lt;m:defJc m:val=&quot;centerGroup&quot;/&gt;\n   &lt;m:wrapIndent m:val=&quot;1440&quot;/&gt;\n   &lt;m:intLim m:val=&quot;subSup&quot;/&gt;\n   &lt;m:naryLim m:val=&quot;undOvr&quot;/&gt;\n  &lt;/m:mathPr&gt;&lt;/w:WordDocument&gt;\n&lt;/xml&gt;&lt;![endif]--&gt;&lt;!--[if gte mso 9]&gt;&lt;xml&gt;\n &lt;w:LatentStyles DefLockedState=&quot;false&quot; DefUnhideWhenUsed=&quot;true&quot;\n  DefSemiHidden=&quot;true&quot; DefQFormat=&quot;false&quot; DefPriority=&quot;99&quot;\n  LatentStyleCount=&quot;267&quot;&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;0&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; QFormat=&quot;true&quot; Name=&quot;Normal&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;9&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; QFormat=&quot;true&quot; Name=&quot;heading 1&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;9&quot; QFormat=&quot;true&quot; Name=&quot;heading 2&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;9&quot; QFormat=&quot;true&quot; Name=&quot;heading 3&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;9&quot; QFormat=&quot;true&quot; Name=&quot;heading 4&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;9&quot; QFormat=&quot;true&quot; Name=&quot;heading 5&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;9&quot; QFormat=&quot;true&quot; Name=&quot;heading 6&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;9&quot; QFormat=&quot;true&quot; Name=&quot;heading 7&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;9&quot; QFormat=&quot;true&quot; Name=&quot;heading 8&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;9&quot; QFormat=&quot;true&quot; Name=&quot;heading 9&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;39&quot; Name=&quot;toc 1&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;39&quot; Name=&quot;toc 2&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;39&quot; Name=&quot;toc 3&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;39&quot; Name=&quot;toc 4&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;39&quot; Name=&quot;toc 5&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;39&quot; Name=&quot;toc 6&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;39&quot; Name=&quot;toc 7&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;39&quot; Name=&quot;toc 8&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;39&quot; Name=&quot;toc 9&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;35&quot; QFormat=&quot;true&quot; Name=&quot;caption&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;10&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; QFormat=&quot;true&quot; Name=&quot;Title&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;1&quot; Name=&quot;Default Paragraph Font&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;11&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; QFormat=&quot;true&quot; Name=&quot;Subtitle&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;22&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; QFormat=&quot;true&quot; Name=&quot;Strong&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;20&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; QFormat=&quot;true&quot; Name=&quot;Emphasis&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;59&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Table Grid&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; UnhideWhenUsed=&quot;false&quot; Name=&quot;Placeholder Text&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;1&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; QFormat=&quot;true&quot; Name=&quot;No Spacing&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;60&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Light Shading&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;61&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Light List&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;62&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Light Grid&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;63&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Shading 1&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;64&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Shading 2&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;65&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium List 1&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;66&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium List 2&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;67&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Grid 1&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;68&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Grid 2&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;69&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Grid 3&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;70&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Dark List&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;71&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Colorful Shading&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;72&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Colorful List&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;73&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Colorful Grid&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;60&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Light Shading Accent 1&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;61&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Light List Accent 1&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;62&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Light Grid Accent 1&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;63&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Shading 1 Accent 1&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;64&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Shading 2 Accent 1&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;65&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium List 1 Accent 1&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; UnhideWhenUsed=&quot;false&quot; Name=&quot;Revision&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;34&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; QFormat=&quot;true&quot; Name=&quot;List Paragraph&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;29&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; QFormat=&quot;true&quot; Name=&quot;Quote&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;30&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; QFormat=&quot;true&quot; Name=&quot;Intense Quote&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;66&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium List 2 Accent 1&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;67&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Grid 1 Accent 1&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;68&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Grid 2 Accent 1&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;69&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Grid 3 Accent 1&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;70&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Dark List Accent 1&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;71&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Colorful Shading Accent 1&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;72&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Colorful List Accent 1&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;73&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Colorful Grid Accent 1&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;60&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Light Shading Accent 2&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;61&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Light List Accent 2&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;62&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Light Grid Accent 2&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;63&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Shading 1 Accent 2&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;64&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Shading 2 Accent 2&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;65&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium List 1 Accent 2&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;66&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium List 2 Accent 2&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;67&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Grid 1 Accent 2&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;68&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Grid 2 Accent 2&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;69&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Grid 3 Accent 2&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;70&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Dark List Accent 2&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;71&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Colorful Shading Accent 2&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;72&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Colorful List Accent 2&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;73&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Colorful Grid Accent 2&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;60&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Light Shading Accent 3&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;61&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Light List Accent 3&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;62&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Light Grid Accent 3&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;63&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Shading 1 Accent 3&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;64&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Shading 2 Accent 3&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;65&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium List 1 Accent 3&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;66&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium List 2 Accent 3&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;67&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Grid 1 Accent 3&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;68&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Grid 2 Accent 3&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;69&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Grid 3 Accent 3&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;70&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Dark List Accent 3&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;71&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Colorful Shading Accent 3&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;72&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Colorful List Accent 3&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;73&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Colorful Grid Accent 3&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;60&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Light Shading Accent 4&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;61&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Light List Accent 4&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;62&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Light Grid Accent 4&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;63&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Shading 1 Accent 4&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;64&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Shading 2 Accent 4&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;65&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium List 1 Accent 4&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;66&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium List 2 Accent 4&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;67&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Grid 1 Accent 4&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;68&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Grid 2 Accent 4&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;69&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Grid 3 Accent 4&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;70&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Dark List Accent 4&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;71&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Colorful Shading Accent 4&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;72&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Colorful List Accent 4&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;73&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Colorful Grid Accent 4&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;60&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Light Shading Accent 5&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;61&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Light List Accent 5&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;62&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Light Grid Accent 5&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;63&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Shading 1 Accent 5&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;64&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Shading 2 Accent 5&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;65&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium List 1 Accent 5&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;66&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium List 2 Accent 5&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;67&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Grid 1 Accent 5&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;68&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Grid 2 Accent 5&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;69&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Grid 3 Accent 5&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;70&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Dark List Accent 5&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;71&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Colorful Shading Accent 5&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;72&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Colorful List Accent 5&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;73&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Colorful Grid Accent 5&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;60&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Light Shading Accent 6&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;61&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Light List Accent 6&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;62&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Light Grid Accent 6&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;63&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Shading 1 Accent 6&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;64&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Shading 2 Accent 6&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;65&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium List 1 Accent 6&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;66&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium List 2 Accent 6&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;67&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Grid 1 Accent 6&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;68&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Grid 2 Accent 6&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;69&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Medium Grid 3 Accent 6&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;70&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Dark List Accent 6&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;71&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Colorful Shading Accent 6&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;72&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Colorful List Accent 6&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;73&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; Name=&quot;Colorful Grid Accent 6&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;19&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; QFormat=&quot;true&quot; Name=&quot;Subtle Emphasis&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;21&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; QFormat=&quot;true&quot; Name=&quot;Intense Emphasis&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;31&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; QFormat=&quot;true&quot; Name=&quot;Subtle Reference&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;32&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; QFormat=&quot;true&quot; Name=&quot;Intense Reference&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;33&quot; SemiHidden=&quot;false&quot;\n   UnhideWhenUsed=&quot;false&quot; QFormat=&quot;true&quot; Name=&quot;Book Title&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;37&quot; Name=&quot;Bibliography&quot;/&gt;\n  &lt;w:LsdException Locked=&quot;false&quot; Priority=&quot;39&quot; QFormat=&quot;true&quot; Name=&quot;TOC Heading&quot;/&gt;\n &lt;/w:LatentStyles&gt;\n&lt;/xml&gt;&lt;![endif]--&gt;&lt;style&gt;\n&lt;!--\n /* Font Definitions */\n @font-face\n	{font-family:&quot;Cambria Math&quot;;\n	panose-1:2 4 5 3 5 4 6 3 2 4;\n	mso-font-charset:1;\n	mso-generic-font-family:roman;\n	mso-font-format:other;\n	mso-font-pitch:variable;\n	mso-font-signature:0 0 0 0 0 0;}\n@font-face\n	{font-family:Calibri;\n	panose-1:2 15 5 2 2 2 4 3 2 4;\n	mso-font-charset:204;\n	mso-generic-font-family:swiss;\n	mso-font-pitch:variable;\n	mso-font-signature:-1610611985 1073750139 0 0 159 0;}\n /* Style Definitions */\n p.MsoNormal, li.MsoNormal, div.MsoNormal\n	{mso-style-unhide:no;\n	mso-style-qformat:yes;\n	mso-style-parent:&quot;&quot;;\n	margin-top:0cm;\n	margin-right:0cm;\n	margin-bottom:10.0pt;\n	margin-left:0cm;\n	line-height:115%;\n	mso-pagination:widow-orphan;\n	font-size:11.0pt;\n	font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;;\n	mso-ascii-font-family:Calibri;\n	mso-ascii-theme-font:minor-latin;\n	mso-fareast-font-family:Calibri;\n	mso-fareast-theme-font:minor-latin;\n	mso-hansi-font-family:Calibri;\n	mso-hansi-theme-font:minor-latin;\n	mso-bidi-font-family:&quot;Times New Roman&quot;;\n	mso-bidi-theme-font:minor-bidi;\n	mso-fareast-language:EN-US;}\n.MsoChpDefault\n	{mso-style-type:export-only;\n	mso-default-props:yes;\n	mso-ascii-font-family:Calibri;\n	mso-ascii-theme-font:minor-latin;\n	mso-fareast-font-family:Calibri;\n	mso-fareast-theme-font:minor-latin;\n	mso-hansi-font-family:Calibri;\n	mso-hansi-theme-font:minor-latin;\n	mso-bidi-font-family:&quot;Times New Roman&quot;;\n	mso-bidi-theme-font:minor-bidi;\n	mso-fareast-language:EN-US;}\n.MsoPapDefault\n	{mso-style-type:export-only;\n	margin-bottom:10.0pt;\n	line-height:115%;}\n@page Section1\n	{size:595.3pt 841.9pt;\n	margin:2.0cm 42.5pt 2.0cm 3.0cm;\n	mso-header-margin:35.4pt;\n	mso-footer-margin:35.4pt;\n	mso-paper-source:0;}\ndiv.Section1\n	{page:Section1;}\n--&gt;\n&lt;/style&gt;&lt;!--[if gte mso 10]&gt;\n&lt;style&gt;\n /* Style Definitions */\n table.MsoNormalTable\n	{mso-style-name:&quot;Обычная таблица&quot;;\n	mso-tstyle-rowband-size:0;\n	mso-tstyle-colband-size:0;\n	mso-style-noshow:yes;\n	mso-style-priority:99;\n	mso-style-qformat:yes;\n	mso-style-parent:&quot;&quot;;\n	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;\n	mso-para-margin-top:0cm;\n	mso-para-margin-right:0cm;\n	mso-para-margin-bottom:10.0pt;\n	mso-para-margin-left:0cm;\n	line-height:115%;\n	mso-pagination:widow-orphan;\n	font-size:11.0pt;\n	font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;;\n	mso-ascii-font-family:Calibri;\n	mso-ascii-theme-font:minor-latin;\n	mso-fareast-font-family:&quot;Times New Roman&quot;;\n	mso-fareast-theme-font:minor-fareast;\n	mso-hansi-font-family:Calibri;\n	mso-hansi-theme-font:minor-latin;}\n&lt;/style&gt;\n&lt;![endif]--&gt;\n\n&lt;p class=&quot;MsoNormal&quot;&gt;Схема проезда на производственную площадку.&lt;/p&gt;',0.0000000000000000000,97)	;
#	TC`curs`utf8_general_ci	;
CREATE TABLE `curs` (
  `title` varchar(4) NOT NULL,
  `value` float(6,3) NOT NULL DEFAULT '0.000',
  `znak` varchar(7) NOT NULL,
  PRIMARY KEY (`title`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TD`curs`utf8_general_ci	;
INSERT INTO `curs` VALUES 
('USD',29.000,'$'),
('EURO',45.123,'&euro;'),
('RUR',1.000,'руб.')	;
#	TC`data`utf8_general_ci	;
CREATE TABLE `data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  `tovar` int(11) DEFAULT NULL,
  `options` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tovar` (`tovar`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='Данные к товарам'	;
#	TD`data`utf8_general_ci	;
INSERT INTO `data` VALUES 
(2,'D35х16мм,',3,0),
(6,'100 г',2,2),
(8,'120 г',3,2),
(9,'200x100x21',3,6)	;
#	TC`discount`utf8_general_ci	;
CREATE TABLE `discount` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` int(11) NOT NULL,
  `value` float(4,1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8	;
#	TD`discount`utf8_general_ci	;
INSERT INTO `discount` VALUES 
(1,5000,3.0),
(2,2000,1.0),
(3,25000,4.0),
(4,100000,5.0)	;
#	TC`firm`utf8_general_ci	;
CREATE TABLE `firm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8	;
#	TD`firm`utf8_general_ci	;
INSERT INTO `firm` VALUES 
(2,'АКТИВ ПЛЮС'),
(3,'Sindy'),
(4,'Eko-style'),
(5,'Россия'),
(6,'Luxalon'),
(7,'Clipso'),
(8,'Швейцария'),
(9,'Армения'),
(10,'GVT- MKRTCHYANNER'),
(11,'Китай'),
(12,'Ozkardezler (Турция)'),
(13,'GVT (Армения)'),
(14,'Ferrari (Италия)')	;
#	TC`grp`utf8_general_ci	;
CREATE TABLE `grp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`grp`utf8_general_ci	;
INSERT INTO `grp` VALUES 
(0,'Нет группы'),
(3,'Серия1')	;
#	TC`maket`utf8_general_ci	;
CREATE TABLE `maket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `titleEN` varchar(120) NOT NULL,
  `date2` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8	;
#	TD`maket`utf8_general_ci	;
INSERT INTO `maket` VALUES 
(26,1275755059,'Сравнение товаров','Sravnenie-tovarov',1275757223),
(25,1275639913,'Тестовый макет','Testoviy-maket',1275641648),
(24,1273793800,'ТермоАльянс','TermoAlyans',1275481684),
(22,1273769841,'Название макета-22','Nazvanie-maketa-22',1273782747),
(23,1273769960,'Актив Плюс','Nazvanie-maketa-23',1275580924)	;
#	TC`moduleData`utf8_general_ci	;
CREATE TABLE `moduleData` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `modules` int(11) NOT NULL,
  `var` varchar(100) NOT NULL,
  `value` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8	;
#	TD`moduleData`utf8_general_ci	;
INSERT INTO `moduleData` VALUES 
(11,4,'description','Лента новостей'),
(10,4,'keywords','Лента новостей'),
(9,4,'title','Лента новостей')	;
#	TC`modules`utf8_general_ci	;
CREATE TABLE `modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `maket` int(11) NOT NULL,
  `shablon` int(11) NOT NULL,
  `date_` int(11) NOT NULL,
  `date2` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  `titleEN` varchar(280) NOT NULL,
  `enURL` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8	;
#	TD`modules`utf8_general_ci	;
INSERT INTO `modules` VALUES 
(4,0,1,0,4,1275484979,1275578143,'Лента новостей','Lenta-novostey','news'),
(3,90,1,0,0,1275481753,1275581432,'Каталог товаров','Katalog-tovarov','Katalog-2'),
(6,0,1,0,0,1275565077,1275643695,'Верхнее меню','Verhnee-menyu',''),
(7,0,1,0,6,1275598020,1275600016,'Корзина покупателя','Korzina-pokupatelya','busket'),
(8,0,1,0,7,1275732376,1275753554,'Вывод конкретного товара','Vivod-konkretnogo-tovara','buy'),
(9,0,1,0,0,1275754494,1275754494,'Маленькая корзина покупателя','Malenkaya-korzina-pokupatelya',''),
(10,0,1,26,8,1275754906,1275754906,'Сравнение товаров','Sravnenie-tovarov','compare')	;
#	TC`news`utf8_general_ci	;
CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  `date_` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`news`utf8_general_ci	;
INSERT INTO `news` VALUES 
(1,'Открытие магазина&lt;br&gt;',1275575362)	;
#	TC`options`utf8_general_ci	;
CREATE TABLE `options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `main` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8	;
#	TD`options`utf8_general_ci	;
INSERT INTO `options` VALUES 
(6,'Габариты',0),
(2,'Вес',1)	;
#	TC`orderData`utf8_general_ci	;
CREATE TABLE `orderData` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tovarId` int(11) NOT NULL DEFAULT '0',
  `price` float(10,2) NOT NULL DEFAULT '0.00',
  `valuta` varchar(5) NOT NULL DEFAULT '',
  `orders` int(11) DEFAULT NULL,
  `col` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8	;
#	TD`orderData`utf8_general_ci	;
INSERT INTO `orderData` VALUES 
(23,4,4000.00,'RUR',17,1),
(17,4,123.00,'EURO',15,1),
(22,3,2500.00,'RUR',17,2),
(24,3,2000.00,'RUR',18,1),
(25,4,119.31,'EURO',19,1),
(26,2,3000.00,'RUR',20,1),
(36,2,414.00,'RUR',22,1)	;
#	TC`orders`utf8_general_ci	;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fio` varchar(100) NOT NULL DEFAULT '',
  `contact` text NOT NULL,
  `tel` varchar(100) NOT NULL DEFAULT '',
  `date_` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(20) NOT NULL DEFAULT '',
  `users` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8	;
#	TD`orders`utf8_general_ci	;
INSERT INTO `orders` VALUES 
(15,'Дроздов Александр Алексеевич','Адрес: ул. Дм. Устинова, 5, 143 Skype: DrozdovAA','+7 911 160 24 13',1263159510,3,'127.0.0.1',1),
(17,'Alexandr','123','1213',1264282185,2,'127.0.0.1',0),
(18,'12312','89111602413 DrozdovAA@bk.ru','(495) 519-90-82',1264284792,2,'127.0.0.1',0),
(19,'Дроздов Александр Алексеевич','Адрес: ул. Дм. Устинова, 5, 143 Skype: DrozdovAA','+7 911 160 24 13',1264287330,3,'127.0.0.1',1),
(20,'Alexandr','Адрес: ул. Дм. Устинова, 5, 143 Skype: DrozdovAA','89111602413',1265180829,2,'127.0.0.1',0),
(22,'','','',1275598792,2,'127.0.0.1',0)	;
#	TC`shablon`utf8_general_ci	;
CREATE TABLE `shablon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `titleEN` varchar(120) NOT NULL,
  `date2` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8	;
#	TD`shablon`utf8_general_ci	;
INSERT INTO `shablon` VALUES 
(1,1273784695,'Основной шаблон','Nazvanie-shablona',1275578317),
(5,1275578411,'Каталог товаров','Katalog-tovarov',1275939418),
(4,1275574507,'Лента новостей','Lenta-novostey',1275574507),
(6,1275598190,'Корзина покупателя','Nazvanie-shablona',1275599111),
(7,1275733226,'Вывод товара','Nazvanie-shablona',1275753086),
(8,1275755087,'Сравнение товаров шаблон','Sravnenie-tovarov-shablon',1275757170)	;
#	TC`spec`utf8_general_ci	;
CREATE TABLE `spec` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date1` int(11) NOT NULL,
  `date2` int(11) NOT NULL,
  `price` float(10,2) NOT NULL,
  `tovar` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8	;
#	TD`spec`utf8_general_ci	;
INSERT INTO `spec` VALUES 
(2,1267390800,1269723600,1000.00,4),
(3,1267390800,1277841600,900.00,2)	;
#	TC`tovar`utf8_general_ci	;
CREATE TABLE `tovar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text,
  `category` int(11) DEFAULT NULL,
  `price` float(9,2) DEFAULT NULL,
  `firm` int(11) NOT NULL DEFAULT '0',
  `about` text NOT NULL,
  `valuta` varchar(4) NOT NULL DEFAULT 'RUR',
  `price2` float(10,2) DEFAULT '0.00',
  `also` int(11) NOT NULL DEFAULT '0',
  `grp` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `category` (`category`),
  KEY `firm` (`firm`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8	;
#	TD`tovar`utf8_general_ci	;
INSERT INTO `tovar` VALUES 
(2,'Крышка круглая для стеклянной петли',15,\N,4,'Крышка круглая для стеклянной петли. Артикул: G2264. Материал: пластмасса. Цвет: хром. Количество в упаковке: 500 ед. Вес 1 единицы: 0,005 кг. Производитель: Ferrari (Италия).','RUR',1120.00,1,0),
(3,'Ручка мебельная, врезная',30,\N,5,'Цвет белый №23','RUR',122.00,0,0)	;
#	TC`users`utf8_general_ci	;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fio` text NOT NULL,
  `login` varchar(100) NOT NULL,
  `pwd` varchar(32) NOT NULL,
  `contact` text NOT NULL,
  `tel` varchar(100) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`users`utf8_general_ci	;
INSERT INTO `users` VALUES 
(1,'Дроздов Александр Алексеевич','DrozdovAA','5fb8a0f57d20f649aa99b5d43d8ff784','Адрес: ул. Дм. Устинова, 5, 143\r\nSkype: DrozdovAA','+7 911 160 24 13',1),
(2,'Александр','lgn','2fd55a871173f51e0897c96dccc18f67','123','89111602413',1)	;
